# skin.carp-xtouch
Kodi skin for small touch screens

