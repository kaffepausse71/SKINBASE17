import os
import xbmc


os.system("sudo /usr/bin/modem3g/sakis3g disconnect");
