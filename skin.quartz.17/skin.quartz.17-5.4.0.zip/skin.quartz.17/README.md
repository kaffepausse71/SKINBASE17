# Quartz skin for KODI
Visit following site for more information: http://forum.kodi.tv/showthread.php?tid=309612

# Intro
Before starting this thread I'd like to mention that this skin wouldn't be here if it wasn't because of the hard work of Pecinko, credits go to him.

As you all probably know Quartz was originally created by Pecinko. After putting all his effort in Quartz 4, version 5 of his skin was born. Up to recently there was a post for Quartz 5 development lead by Pecinko himself. After having seen all this great work I decided to put myself on the development of this skin to. As you can see I've made a fork of Pecinko his skin. To check out the git repository of Pecinko click here.

So, what to expect from this new thread? In short, you'll find the different links to Git, where you'll be able to download the skin. Next to that the goal is also to get your feedback or possible enhancements I could implement for this skin. I would like to accentuate that I would happily merge other forks into this Quartz version if this is requested. Next to that you'll find different polls etc.

# Notice
As you all know Krypton is already there.. currently this skin will only work on Jarvis. Effort is being put in this skin to port it.. any help is greatly appreciated off course. In the meanwhile certainly report any bugs or weird behavior, I'll try to fix those along the way. 

# Download

Click following link or select 'Download as ZIP' in github:
https://github.com/TPX01/skin.quartz.krypton/archive/master.zip

Latest Krypton release:
No stable releases yet, this means that the master will also contain .cmd, psd files, etc

# Todo
no new features scheduled until the build is more stable

# Issues
Did you see a bug? Report it by going to the issues section!

https://github.com/TPX01/skin.quartz.krypton/issues

