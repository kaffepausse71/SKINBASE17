The main goal of this branch is to add Krypton support to this very fine skin made by JezzX.

Comment on [this thread](http://forum.kodi.tv/showthread.php?tid=298901) thread if you have requests or bugs to reports.
