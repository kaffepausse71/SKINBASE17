Pellucid
===================

Pellucid is a skin for Kodi Media Centre.

Built for the living room, Pellucid is a clean and simple Kodi experience designed for maximum usability and minimum fuss.

Skin Shortcuts addon support is available from the Krypton release onwards.

Discussion thread: http://forum.kodi.tv/forumdisplay.php?fid=267

Created by theDeadMan with love from Bristol, U.K.

