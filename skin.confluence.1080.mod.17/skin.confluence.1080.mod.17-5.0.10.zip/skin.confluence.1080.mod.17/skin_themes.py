#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,os,sys,shutil

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')

_skin_id_ = xbmc.getSkinDir()
_addon_ =  xbmcaddon.Addon(id = _skin_id_)
_addon_path_ = en_de_code_path(xbmc.translatePath(_addon_.getAddonInfo('path')))

_skin_dir_name_ = xbmc.getSkinDir()
_data_path_ = os.path.join(_addon_path_,'skin_themes')
_skin_backgrounds_path_ = os.path.join(_addon_path_,'backgrounds')

def img_folder_list_array(dir_path):
    img_folder_array=[]
    for folder in os.listdir(dir_path):
        img_folder_array.append(folder)
    return img_folder_array

def delete_files(dir_path):
    for file in os.listdir(dir_path):
        full_file_path = os.path.join(dir_path,file)
        if os.path.exists(full_file_path):
            try:os.remove(full_file_path)
            except:pass

def reload_skin():
    xbmc.executebuiltin("UnloadSkin()")
    xbmc.sleep(50)
    xbmc.executebuiltin("ReloadSkin()")

def copy_files(files_path,destination_path):
    delete_files(destination_path)
    for file in os.listdir(files_path):
        start_path = os.path.join(files_path,file)
        ziel_path = os.path.join(destination_path,file)
        try:
            shutil.copy(start_path,ziel_path)
            reload_skin()
        except:
               pass

my_img_folder_list =[]			   
my_img_folder_list = img_folder_list_array(_data_path_)
if len(my_img_folder_list) > 0:

    call = xbmcgui.Dialog().select('[COLOR lime]SKIN THEMES LOADER[/COLOR]', my_img_folder_list)
    if call == -1:sys.exit(0)
    elif call > -1:copy_files(os.path.join(_data_path_,my_img_folder_list[call]),_skin_backgrounds_path_)
    sys.exit(0)

### loki1979 - 25.11.2017 ###