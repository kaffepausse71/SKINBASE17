# Kodiflix Skin for Kodi Krypton" by "SchisM"

## Installation instructions:
>     
>      1. search for the green button "clone or download" click it -> download zip
>      2. In Kodi, go to Settings --> AddOns --> Install from zip -> choose the source where you saved the .zip
>      3. Select **skin.kodiflix.krypton.zip** and hit install

